package com.dianshan.ecommerce;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.dianshan.ecommerce.mapper")
public class DianshanEcommerceApplication {

    public static void main(String[] args) {
        SpringApplication.run(DianshanEcommerceApplication.class, args);
    }
}