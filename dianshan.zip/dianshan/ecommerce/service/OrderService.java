package com.dianshan.ecommerce.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dianshan.ecommerce.dto.OrderCreateDTO;
import com.dianshan.ecommerce.entity.Order;
import java.util.List;

public interface OrderService {
    Order createOrder(Long userId, OrderCreateDTO dto);
    Order getById(Long id, Long userId);
    Page<Order> getOrdersByUserId(Long userId, Integer pageNum, Integer pageSize);
    void cancelOrder(Long id, Long userId);
    void payOrder(Long id, Long userId);
    void deleteOrder(Long id, Long userId);
}