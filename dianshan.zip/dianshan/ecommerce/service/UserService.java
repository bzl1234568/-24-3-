package com.dianshan.ecommerce.service;

import com.dianshan.ecommerce.entity.User;

public interface UserService {
    User getByUsername(String username);
    User getById(Long id);
    String login(String username, String password);
    User register(String username, String password, String nickname);
}