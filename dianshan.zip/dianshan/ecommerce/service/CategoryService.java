package com.dianshan.ecommerce.service;

import com.dianshan.ecommerce.entity.Category;
import java.util.List;

public interface CategoryService {
    List<Category> getAllCategories();
    List<Category> getCategoriesByParentId(Long parentId);
    Category getById(Long id);
}