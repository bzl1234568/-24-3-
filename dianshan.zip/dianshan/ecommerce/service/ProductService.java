package com.dianshan.ecommerce.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dianshan.ecommerce.dto.ProductQueryDTO;
import com.dianshan.ecommerce.entity.Product;
import java.util.List;

public interface ProductService {
    Page<Product> queryProducts(ProductQueryDTO queryDTO);
    Product getById(Long id);
    List<Product> getHotProducts(int limit);
    Product create(Product product);
    Product update(Product product);
    void delete(Long id);
}