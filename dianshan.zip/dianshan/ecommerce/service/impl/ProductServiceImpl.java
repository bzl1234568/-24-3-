package com.dianshan.ecommerce.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dianshan.ecommerce.dto.ProductQueryDTO;
import com.dianshan.ecommerce.entity.Product;
import com.dianshan.ecommerce.exception.BusinessException;
import com.dianshan.ecommerce.mapper.ProductMapper;
import com.dianshan.ecommerce.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {
    
    @Autowired
    private ProductMapper productMapper;
    
    @Override
    public Page<Product> queryProducts(ProductQueryDTO queryDTO) {
        Page<Product> page = new Page<>(queryDTO.getPageNum(), queryDTO.getPageSize());
        
        LambdaQueryWrapper<Product> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Product::getStatus, 1);
        
        if (queryDTO.getCategoryId() != null) {
            wrapper.eq(Product::getCategoryId, queryDTO.getCategoryId());
        }
        
        if (StringUtils.hasText(queryDTO.getKeyword())) {
            wrapper.like(Product::getName, queryDTO.getKeyword());
        }
        
        wrapper.orderByDesc(Product::getCreatedAt);
        
        return productMapper.selectPage(page, wrapper);
    }
    
    @Override
    public Product getById(Long id) {
        Product product = productMapper.selectById(id);
        if (product == null || product.getStatus() != 1) {
            throw new BusinessException("商品不存在");
        }
        return product;
    }
    
    @Override
    public List<Product> getHotProducts(int limit) {
        LambdaQueryWrapper<Product> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Product::getStatus, 1)
                .orderByDesc(Product::getSales)
                .last("LIMIT " + limit);
        return productMapper.selectList(wrapper);
    }
    
    @Override
    public Product create(Product product) {
        product.setStatus(1);
        product.setSales(0);
        productMapper.insert(product);
        return product;
    }
    
    @Override
    public Product update(Product product) {
        Product existProduct = productMapper.selectById(product.getId());
        if (existProduct == null) {
            throw new BusinessException("商品不存在");
        }
        productMapper.updateById(product);
        return product;
    }
    
    @Override
    public void delete(Long id) {
        productMapper.deleteById(id);
    }
}