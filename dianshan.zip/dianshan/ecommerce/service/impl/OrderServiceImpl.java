package com.dianshan.ecommerce.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dianshan.ecommerce.dto.OrderCreateDTO;
import com.dianshan.ecommerce.entity.Order;
import com.dianshan.ecommerce.entity.OrderItem;
import com.dianshan.ecommerce.entity.Product;
import com.dianshan.ecommerce.exception.BusinessException;
import com.dianshan.ecommerce.mapper.OrderItemMapper;
import com.dianshan.ecommerce.mapper.OrderMapper;
import com.dianshan.ecommerce.mapper.ProductMapper;
import com.dianshan.ecommerce.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

@Service
public class OrderServiceImpl implements OrderService {
    
    @Autowired
    private OrderMapper orderMapper;
    
    @Autowired
    private OrderItemMapper orderItemMapper;
    
    @Autowired
    private ProductMapper productMapper;
    
    @Override
    @Transactional
    public Order createOrder(Long userId, OrderCreateDTO dto) {
        Order order = new Order();
        order.setOrderNo(generateOrderNo());
        order.setUserId(userId);
        order.setStatus(0);
        order.setPaymentType(dto.getPaymentType());
        order.setConsignee(dto.getConsignee());
        order.setPhone(dto.getPhone());
        order.setAddress(dto.getAddress());
        order.setRemark(dto.getRemark());
        order.setFreightAmount(BigDecimal.ZERO);
        order.setDiscountAmount(BigDecimal.ZERO);
        
        BigDecimal totalAmount = BigDecimal.ZERO;
        
        for (OrderCreateDTO.OrderItemDTO itemDTO : dto.getItems()) {
            Product product = productMapper.selectById(itemDTO.getProductId());
            if (product == null || product.getStatus() != 1) {
                throw new BusinessException("商品不存在: " + itemDTO.getProductId());
            }
            
            if (product.getStock() < itemDTO.getQuantity()) {
                throw new BusinessException("商品库存不足: " + product.getName());
            }
            
            BigDecimal price = getEffectivePrice(product);
            BigDecimal itemTotal = price.multiply(BigDecimal.valueOf(itemDTO.getQuantity()));
            totalAmount = totalAmount.add(itemTotal);
            
            OrderItem orderItem = new OrderItem();
            orderItem.setProductId(product.getId());
            orderItem.setProductName(product.getName());
            orderItem.setProductImage(product.getMainImage());
            orderItem.setPrice(price);
            orderItem.setQuantity(itemDTO.getQuantity());
            orderItem.setTotalAmount(itemTotal);
            
            product.setStock(product.getStock() - itemDTO.getQuantity());
            product.setSales(product.getSales() + itemDTO.getQuantity());
            productMapper.updateById(product);
        }
        
        order.setTotalAmount(totalAmount);
        order.setPayAmount(totalAmount);
        
        orderMapper.insert(order);
        
        for (OrderCreateDTO.OrderItemDTO itemDTO : dto.getItems()) {
            Product product = productMapper.selectById(itemDTO.getProductId());
            BigDecimal price = getEffectivePrice(product);
            
            OrderItem orderItem = new OrderItem();
            orderItem.setOrderId(order.getId());
            orderItem.setProductId(product.getId());
            orderItem.setProductName(product.getName());
            orderItem.setProductImage(product.getMainImage());
            orderItem.setPrice(price);
            orderItem.setQuantity(itemDTO.getQuantity());
            orderItem.setTotalAmount(price.multiply(BigDecimal.valueOf(itemDTO.getQuantity())));
            orderItemMapper.insert(orderItem);
        }
        
        return order;
    }
    
    private BigDecimal getEffectivePrice(Product product) {
        if (product.getPromotionType() != null && product.getPromotionType() > 0 
                && product.getPromotionPrice() != null) {
            LocalDateTime now = LocalDateTime.now();
            if (product.getPromotionStartTime() != null && product.getPromotionEndTime() != null
                    && now.isAfter(product.getPromotionStartTime()) 
                    && now.isBefore(product.getPromotionEndTime())) {
                return product.getPromotionPrice();
            }
        }
        return product.getPrice();
    }
    
    private String generateOrderNo() {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        String random = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        return "ORD" + timestamp + random;
    }
    
    @Override
    public Order getById(Long id, Long userId) {
        Order order = orderMapper.selectOne(
                new LambdaQueryWrapper<Order>()
                        .eq(Order::getId, id)
                        .eq(Order::getUserId, userId)
        );
        if (order == null) {
            throw new BusinessException("订单不存在");
        }
        
        List<OrderItem> items = orderItemMapper.selectList(
                new LambdaQueryWrapper<OrderItem>().eq(OrderItem::getOrderId, id)
        );
        order.setItems(items);
        return order;
    }
    
    @Override
    public Page<Order> getOrdersByUserId(Long userId, Integer pageNum, Integer pageSize) {
        Page<Order> page = new Page<>(pageNum, pageSize);
        Page<Order> orderPage = orderMapper.selectPage(page,
                new LambdaQueryWrapper<Order>()
                        .eq(Order::getUserId, userId)
                        .orderByDesc(Order::getCreatedAt)
        );
        
        for (Order order : orderPage.getRecords()) {
            List<OrderItem> items = orderItemMapper.selectList(
                    new LambdaQueryWrapper<OrderItem>().eq(OrderItem::getOrderId, order.getId())
            );
            order.setItems(items);
        }
        
        return orderPage;
    }
    
    @Override
    @Transactional
    public void cancelOrder(Long id, Long userId) {
        Order order = getById(id, userId);
        if (order.getStatus() != 0) {
            throw new BusinessException("只能取消待付款订单");
        }
        
        order.setStatus(4);
        orderMapper.updateById(order);
        
        for (OrderItem item : order.getItems()) {
            Product product = productMapper.selectById(item.getProductId());
            if (product != null) {
                product.setStock(product.getStock() + item.getQuantity());
                product.setSales(product.getSales() - item.getQuantity());
                productMapper.updateById(product);
            }
        }
    }
    
    @Override
    @Transactional
    public void payOrder(Long id, Long userId) {
        Order order = getById(id, userId);
        if (order.getStatus() != 0) {
            throw new BusinessException("订单状态不正确");
        }
        
        order.setStatus(1);
        order.setPaymentTime(LocalDateTime.now());
        orderMapper.updateById(order);
    }
    
    @Override
    @Transactional
    public void deleteOrder(Long id, Long userId) {
        Order order = getById(id, userId);
        if (order.getStatus() != 4 && order.getStatus() != 3) {
            throw new BusinessException("只能删除已取消或已完成的订单");
        }
        
        orderMapper.deleteById(id);
    }
}