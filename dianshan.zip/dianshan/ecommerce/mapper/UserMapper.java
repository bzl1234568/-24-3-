package com.dianshan.ecommerce.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dianshan.ecommerce.entity.User;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper extends BaseMapper<User> {
}