package com.dianshan.ecommerce.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dianshan.ecommerce.entity.OrderItem;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;

@Mapper
public interface OrderItemMapper extends BaseMapper<OrderItem> {
    
    List<OrderItem> selectByOrderId(Long orderId);
}