package com.dianshan.ecommerce.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dianshan.ecommerce.entity.Product;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProductMapper extends BaseMapper<Product> {
}