package com.dianshan.ecommerce.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dianshan.ecommerce.entity.Order;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import java.util.List;

@Mapper
public interface OrderMapper extends BaseMapper<Order> {
    
    @Select("SELECT o.*, " +
            "GROUP_CONCAT(oi.id) as item_ids " +
            "FROM `order` o " +
            "LEFT JOIN order_item oi ON o.id = oi.order_id " +
            "WHERE o.user_id = #{userId} AND o.deleted = 0 " +
            "GROUP BY o.id " +
            "ORDER BY o.created_at DESC")
    List<Order> selectOrdersWithItems(Long userId);
}