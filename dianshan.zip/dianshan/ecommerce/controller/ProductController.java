package com.dianshan.ecommerce.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dianshan.ecommerce.dto.ProductQueryDTO;
import com.dianshan.ecommerce.entity.Product;
import com.dianshan.ecommerce.service.ProductService;
import com.dianshan.ecommerce.vo.PageResult;
import com.dianshan.ecommerce.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {
    
    @Autowired
    private ProductService productService;
    
    @GetMapping
    public Result<PageResult<Product>> queryProducts(ProductQueryDTO queryDTO) {
        Page<Product> page = productService.queryProducts(queryDTO);
        PageResult<Product> result = PageResult.of(
                page.getRecords(),
                page.getTotal(),
                (int) page.getCurrent(),
                (int) page.getSize()
        );
        return Result.success(result);
    }
    
    @GetMapping("/{id}")
    public Result<Product> getProduct(@PathVariable Long id) {
        Product product = productService.getById(id);
        return Result.success(product);
    }
    
    @GetMapping("/hot")
    public Result<List<Product>> getHotProducts(@RequestParam(defaultValue = "10") int limit) {
        List<Product> products = productService.getHotProducts(limit);
        return Result.success(products);
    }
    
    @PostMapping
    public Result<Product> createProduct(@RequestBody Product product) {
        Product created = productService.create(product);
        return Result.success(created);
    }
    
    @PutMapping("/{id}")
    public Result<Product> updateProduct(@PathVariable Long id, @RequestBody Product product) {
        product.setId(id);
        Product updated = productService.update(product);
        return Result.success(updated);
    }
    
    @DeleteMapping("/{id}")
    public Result<Void> deleteProduct(@PathVariable Long id) {
        productService.delete(id);
        return Result.success();
    }
}