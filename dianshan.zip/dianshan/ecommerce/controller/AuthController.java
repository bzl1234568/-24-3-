package com.dianshan.ecommerce.controller;

import com.dianshan.ecommerce.dto.LoginDTO;
import com.dianshan.ecommerce.entity.User;
import com.dianshan.ecommerce.service.UserService;
import com.dianshan.ecommerce.vo.Result;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    
    @Autowired
    private UserService userService;
    
    @PostMapping("/login")
    public Result<Map<String, Object>> login(@Valid @RequestBody LoginDTO loginDTO) {
        String token = userService.login(loginDTO.getUsername(), loginDTO.getPassword());
        User user = userService.getByUsername(loginDTO.getUsername());
        
        Map<String, Object> data = new HashMap<>();
        data.put("token", token);
        data.put("user", user);
        
        return Result.success(data);
    }
    
    @PostMapping("/register")
    public Result<User> register(@Valid @RequestBody LoginDTO loginDTO) {
        User user = userService.register(
                loginDTO.getUsername(),
                loginDTO.getPassword(),
                null
        );
        return Result.success(user);
    }
    
    @GetMapping("/info")
    public Result<User> getUserInfo(@RequestAttribute("userId") Long userId) {
        User user = userService.getById(userId);
        user.setPassword(null);
        return Result.success(user);
    }
}