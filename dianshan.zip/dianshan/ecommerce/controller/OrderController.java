package com.dianshan.ecommerce.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dianshan.ecommerce.dto.OrderCreateDTO;
import com.dianshan.ecommerce.entity.Order;
import com.dianshan.ecommerce.service.OrderService;
import com.dianshan.ecommerce.vo.PageResult;
import com.dianshan.ecommerce.vo.Result;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/orders")
public class OrderController {
    
    @Autowired
    private OrderService orderService;
    
    @PostMapping
    public Result<Order> createOrder(
            @RequestAttribute("userId") Long userId,
            @Valid @RequestBody OrderCreateDTO dto
    ) {
        Order order = orderService.createOrder(userId, dto);
        return Result.success(order);
    }
    
    @GetMapping
    public Result<PageResult<Order>> getOrders(
            @RequestAttribute("userId") Long userId,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize
    ) {
        Page<Order> page = orderService.getOrdersByUserId(userId, pageNum, pageSize);
        PageResult<Order> result = PageResult.of(
                page.getRecords(),
                page.getTotal(),
                (int) page.getCurrent(),
                (int) page.getSize()
        );
        return Result.success(result);
    }
    
    @GetMapping("/{id}")
    public Result<Order> getOrder(
            @PathVariable Long id,
            @RequestAttribute("userId") Long userId
    ) {
        Order order = orderService.getById(id, userId);
        return Result.success(order);
    }
    
    @PutMapping("/{id}/cancel")
    public Result<Void> cancelOrder(
            @PathVariable Long id,
            @RequestAttribute("userId") Long userId
    ) {
        orderService.cancelOrder(id, userId);
        return Result.success();
    }
    
    @PutMapping("/{id}/pay")
    public Result<Void> payOrder(
            @PathVariable Long id,
            @RequestAttribute("userId") Long userId
    ) {
        orderService.payOrder(id, userId);
        return Result.success();
    }
    
    @DeleteMapping("/{id}")
    public Result<Void> deleteOrder(
            @PathVariable Long id,
            @RequestAttribute("userId") Long userId
    ) {
        orderService.deleteOrder(id, userId);
        return Result.success();
    }
}