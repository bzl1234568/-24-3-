CREATE TABLE IF NOT EXISTS uav (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          VARCHAR(100)  NOT NULL,
    serial_no     VARCHAR(64)   NOT NULL,
    status        INTEGER       DEFAULT 1,
    ai_model      VARCHAR(128),
    ai_battery_mah INTEGER,
    ai_max_altitude_m INTEGER,
    ai_payload_kg REAL,
    ai_inference_json TEXT,
    remark        VARCHAR(500),
    create_time   VARCHAR(32),
    update_time   VARCHAR(32)
);

INSERT OR IGNORE INTO uav (id, name, serial_no, status, ai_model, ai_battery_mah, ai_max_altitude_m, ai_payload_kg, ai_inference_json, remark)
VALUES (1, '演示无人机-01', 'UAV-DEMO-0001', 1, 'Sim-AI-Quad-X4', 5200, 120, 1.2,
        '{"inference":"local-heuristic","confidence":0.82,"sensors":["RGB","IMU"],"windClass":"B"}',
        'SQLite 内置演示数据');
