package com.uav.management;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.uav.management.mapper")
public class UavManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(UavManagementApplication.class, args);
    }
}
