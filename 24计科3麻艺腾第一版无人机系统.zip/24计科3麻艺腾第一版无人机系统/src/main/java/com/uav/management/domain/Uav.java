package com.uav.management.domain;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 无人机实体
 */
public class Uav implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    @NotBlank(message = "名称不能为空")
    @Size(max = 100, message = "名称长度不能超过100")
    private String name;

    @NotBlank(message = "序列号不能为空")
    @Size(max = 64, message = "序列号长度不能超过64")
    private String serialNo;

    /** 1 正常 0 停用 */
    private Integer status;

    private String aiModel;
    private Integer aiBatteryMah;
    private Integer aiMaxAltitudeM;
    private BigDecimal aiPayloadKg;
    private String aiInferenceJson;

    @Size(max = 500, message = "备注长度不能超过500")
    private String remark;

    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getAiModel() {
        return aiModel;
    }

    public void setAiModel(String aiModel) {
        this.aiModel = aiModel;
    }

    public Integer getAiBatteryMah() {
        return aiBatteryMah;
    }

    public void setAiBatteryMah(Integer aiBatteryMah) {
        this.aiBatteryMah = aiBatteryMah;
    }

    public Integer getAiMaxAltitudeM() {
        return aiMaxAltitudeM;
    }

    public void setAiMaxAltitudeM(Integer aiMaxAltitudeM) {
        this.aiMaxAltitudeM = aiMaxAltitudeM;
    }

    public BigDecimal getAiPayloadKg() {
        return aiPayloadKg;
    }

    public void setAiPayloadKg(BigDecimal aiPayloadKg) {
        this.aiPayloadKg = aiPayloadKg;
    }

    public String getAiInferenceJson() {
        return aiInferenceJson;
    }

    public void setAiInferenceJson(String aiInferenceJson) {
        this.aiInferenceJson = aiInferenceJson;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }
}
