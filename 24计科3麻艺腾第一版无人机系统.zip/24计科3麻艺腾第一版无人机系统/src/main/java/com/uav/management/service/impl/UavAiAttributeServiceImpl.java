package com.uav.management.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uav.management.domain.Uav;
import com.uav.management.service.UavAiAttributeService;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * 本地启发式“AI”：用名称/序列号种子 + 伪随机生成稳定且合理的属性组合
 */
@Service
public class UavAiAttributeServiceImpl implements UavAiAttributeService {

    private static final List<String> MODEL_PREFIXES = Arrays.asList(
            "Sim-AI-Quad", "Sim-AI-Hex", "Sim-AI-FixedWing", "Sim-AI-TiltRotor", "Sim-AI-VTOL"
    );
    private static final List<String> SENSOR_SETS = Arrays.asList(
            "[\"RGB\",\"IMU\"]",
            "[\"RGB\",\"LiDAR\",\"IMU\"]",
            "[\"Thermal\",\"RGB\"]",
            "[\"Multispectral\",\"RGB\",\"GNSS\"]"
    );

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public void enrichAiAttributes(Uav uav) {
        long seed = seed(uav.getName(), uav.getSerialNo());
        Random rnd = new Random(seed);

        String model = MODEL_PREFIXES.get(rnd.nextInt(MODEL_PREFIXES.size())) + "-V" + (rnd.nextInt(3) + 1);
        int battery = 3500 + (1 + rnd.nextInt(7)) * 500;
        int altitude = 80 + (1 + rnd.nextInt(11)) * 10;
        BigDecimal payload = BigDecimal.valueOf(0.5 + rnd.nextDouble() * 2.5).setScale(2, RoundingMode.HALF_UP);

        double confidence = 0.65 + rnd.nextDouble() * 0.3;
        String wind = rnd.nextBoolean() ? "A" : "B";
        String sensors = SENSOR_SETS.get(rnd.nextInt(SENSOR_SETS.size()));

        Map<String, Object> inference = new HashMap<>();
        inference.put("inference", "local-heuristic");
        inference.put("confidence", Math.round(confidence * 100.0) / 100.0);
        inference.put("sensorsJson", sensors);
        inference.put("windClass", wind);
        inference.put("seed", seed);

        uav.setAiModel(model);
        uav.setAiBatteryMah(battery);
        uav.setAiMaxAltitudeM(altitude);
        uav.setAiPayloadKg(payload);
        try {
            uav.setAiInferenceJson(objectMapper.writeValueAsString(inference));
        } catch (JsonProcessingException e) {
            uav.setAiInferenceJson("{\"inference\":\"error\"}");
        }
    }

    private long seed(String name, String serial) {
        String base = (name == null ? "" : name) + "|" + (serial == null ? "" : serial);
        byte[] md5 = DigestUtils.md5Digest(base.getBytes(StandardCharsets.UTF_8));
        long s = 0;
        for (int i = 0; i < 8; i++) {
            s = (s << 8) | (md5[i] & 0xff);
        }
        return s == 0 ? 1L : s;
    }
}
