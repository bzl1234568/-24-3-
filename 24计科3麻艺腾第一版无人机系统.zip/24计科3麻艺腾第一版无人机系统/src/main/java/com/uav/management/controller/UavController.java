package com.uav.management.controller;

import com.github.pagehelper.PageInfo;
import com.uav.management.domain.Uav;
import com.uav.management.domain.query.UavQuery;
import com.uav.management.service.UavService;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/uav")
public class UavController {

    private final UavService uavService;

    public UavController(UavService uavService) {
        this.uavService = uavService;
    }

    @GetMapping("/list")
    @RequiresPermissions("uav:list")
    public String list(UavQuery query,
                       @RequestParam(value = "pageNum", defaultValue = "1") int pageNum,
                       @RequestParam(value = "pageSize", defaultValue = "10") int pageSize,
                       Model model) {
        PageInfo<Uav> page = uavService.page(query, pageNum, pageSize);
        model.addAttribute("page", page);
        model.addAttribute("query", query);
        return "uav/list";
    }

    @GetMapping("/add")
    @RequiresPermissions("uav:add")
    public String add(Model model) {
        Uav uav = new Uav();
        uav.setStatus(1);
        model.addAttribute("uav", uav);
        model.addAttribute("formTitle", "新增无人机");
        return "uav/form";
    }

    @GetMapping("/edit/{id}")
    @RequiresPermissions("uav:edit")
    public String edit(@PathVariable("id") Long id, Model model, RedirectAttributes ra) {
        Uav uav = uavService.getById(id);
        if (uav == null) {
            ra.addFlashAttribute("error", "记录不存在");
            return "redirect:/uav/list";
        }
        model.addAttribute("uav", uav);
        model.addAttribute("formTitle", "编辑无人机");
        return "uav/form";
    }

    @PostMapping("/save")
    @RequiresPermissions(value = {"uav:add", "uav:edit"}, logical = Logical.OR)
    public String save(@Valid @ModelAttribute("uav") Uav uav,
                       BindingResult bindingResult,
                       Model model,
                       RedirectAttributes ra) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("formTitle", uav.getId() == null ? "新增无人机" : "编辑无人机");
            return "uav/form";
        }
        try {
            uavService.save(uav);
            ra.addFlashAttribute("msg", "保存成功，AI 属性已更新");
            return "redirect:/uav/list";
        } catch (IllegalArgumentException ex) {
            ra.addFlashAttribute("error", ex.getMessage());
            if (uav.getId() == null) {
                return "redirect:/uav/add";
            }
            return "redirect:/uav/edit/" + uav.getId();
        }
    }

    @PostMapping("/remove")
    @RequiresPermissions("uav:remove")
    public String remove(@RequestParam("ids") String ids, RedirectAttributes ra) {
        List<Long> idList = Arrays.stream(ids.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .map(Long::valueOf)
                .collect(Collectors.toList());
        uavService.removeByIds(idList);
        ra.addFlashAttribute("msg", "删除成功");
        return "redirect:/uav/list";
    }
}
