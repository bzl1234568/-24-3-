package com.uav.management.mapper;

import com.uav.management.domain.Uav;
import com.uav.management.domain.query.UavQuery;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * 无人机数据访问（注解 SQL，减少 XML）
 */
@Mapper
public interface UavMapper {

    @Select("SELECT id, name, serial_no AS serialNo, status, ai_model AS aiModel, ai_battery_mah AS aiBatteryMah, " +
            "ai_max_altitude_m AS aiMaxAltitudeM, ai_payload_kg AS aiPayloadKg, ai_inference_json AS aiInferenceJson, " +
            "remark, create_time AS createTime, update_time AS updateTime FROM uav WHERE id = #{id}")
    Uav selectById(Long id);

    @Select({
            "<script>",
            "SELECT id, name, serial_no AS serialNo, status, ai_model AS aiModel, ai_battery_mah AS aiBatteryMah, ",
            "ai_max_altitude_m AS aiMaxAltitudeM, ai_payload_kg AS aiPayloadKg, ai_inference_json AS aiInferenceJson, ",
            "remark, create_time AS createTime, update_time AS updateTime FROM uav",
            "<where>",
            "  <if test='nameLike != null'>AND name LIKE #{nameLike}</if>",
            "  <if test='serialNoLike != null'>AND serial_no LIKE #{serialNoLike}</if>",
            "  <if test='status != null'>AND status = #{status}</if>",
            "</where>",
            "ORDER BY id DESC",
            "</script>"
    })
    List<Uav> selectList(UavQuery query);

    @Insert("INSERT INTO uav (name, serial_no, status, ai_model, ai_battery_mah, ai_max_altitude_m, ai_payload_kg, " +
            "ai_inference_json, remark, create_time, update_time) VALUES (#{name}, #{serialNo}, #{status}, #{aiModel}, " +
            "#{aiBatteryMah}, #{aiMaxAltitudeM}, #{aiPayloadKg}, #{aiInferenceJson}, #{remark}, #{createTime}, #{updateTime})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Uav uav);

    @Update("UPDATE uav SET name = #{name}, serial_no = #{serialNo}, status = #{status}, ai_model = #{aiModel}, " +
            "ai_battery_mah = #{aiBatteryMah}, ai_max_altitude_m = #{aiMaxAltitudeM}, ai_payload_kg = #{aiPayloadKg}, " +
            "ai_inference_json = #{aiInferenceJson}, remark = #{remark}, update_time = #{updateTime} WHERE id = #{id}")
    int update(Uav uav);

    @Delete("DELETE FROM uav WHERE id = #{id}")
    int deleteById(Long id);

    @Select("SELECT COUNT(1) FROM uav WHERE serial_no = #{serialNo} AND id != #{excludeId}")
    int countBySerialNoExcludeId(@Param("serialNo") String serialNo, @Param("excludeId") Long excludeId);

    @Select("SELECT COUNT(1) FROM uav WHERE serial_no = #{serialNo}")
    int countBySerialNo(@Param("serialNo") String serialNo);
}
