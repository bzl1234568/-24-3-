package com.uav.management.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.uav.management.domain.Uav;
import com.uav.management.domain.query.UavQuery;
import com.uav.management.mapper.UavMapper;
import com.uav.management.service.UavAiAttributeService;
import com.uav.management.service.UavService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class UavServiceImpl implements UavService {

    private final UavMapper uavMapper;
    private final UavAiAttributeService uavAiAttributeService;

    public UavServiceImpl(UavMapper uavMapper, UavAiAttributeService uavAiAttributeService) {
        this.uavMapper = uavMapper;
        this.uavAiAttributeService = uavAiAttributeService;
    }

    @Override
    public PageInfo<Uav> page(UavQuery query, int pageNum, int pageSize) {
        fillLikePatterns(query);
        PageHelper.startPage(pageNum, pageSize);
        List<Uav> list = uavMapper.selectList(query);
        return new PageInfo<>(list);
    }

    @Override
    public Uav getById(Long id) {
        return uavMapper.selectById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void save(Uav uav) {
        if (uav.getStatus() == null) {
            uav.setStatus(1);
        }
        uavAiAttributeService.enrichAiAttributes(uav);
        LocalDateTime now = LocalDateTime.now();
        if (uav.getId() == null) {
            assertSerialUnique(uav.getSerialNo(), null);
            uav.setCreateTime(now);
            uav.setUpdateTime(now);
            uavMapper.insert(uav);
        } else {
            assertSerialUnique(uav.getSerialNo(), uav.getId());
            uav.setUpdateTime(now);
            uavMapper.update(uav);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void removeByIds(List<Long> ids) {
        if (ids == null) {
            return;
        }
        for (Long id : ids) {
            if (id != null) {
                uavMapper.deleteById(id);
            }
        }
    }

    private void assertSerialUnique(String serialNo, Long excludeId) {
        int count = excludeId == null
                ? uavMapper.countBySerialNo(serialNo)
                : uavMapper.countBySerialNoExcludeId(serialNo, excludeId);
        if (count > 0) {
            throw new IllegalArgumentException("序列号已存在：" + serialNo);
        }
    }

    private void fillLikePatterns(UavQuery query) {
        if (StringUtils.hasText(query.getName())) {
            query.setNameLike("%" + sanitizeLikePattern(query.getName().trim()) + "%");
        }
        if (StringUtils.hasText(query.getSerialNo())) {
            query.setSerialNoLike("%" + sanitizeLikePattern(query.getSerialNo().trim()) + "%");
        }
    }

    /** 去掉通配符，避免用户输入放大匹配范围（仍使用参数绑定防注入） */
    private static String sanitizeLikePattern(String raw) {
        return raw.replace("%", "").replace("_", "").replace("\\", "");
    }
}
