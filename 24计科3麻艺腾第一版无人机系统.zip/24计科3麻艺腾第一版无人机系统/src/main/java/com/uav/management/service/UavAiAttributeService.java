package com.uav.management.service;

import com.uav.management.domain.Uav;

/**
 * 模拟 AI 属性推理：根据名称/序列号等生成无人机技术属性（可替换为真实模型服务）
 */
public interface UavAiAttributeService {

    /**
     * 将推理结果写入实体（覆盖 AI 相关字段）
     */
    void enrichAiAttributes(Uav uav);
}
