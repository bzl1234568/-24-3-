package com.uav.management.interceptor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.lang.NonNull;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;
import java.util.stream.Collectors;


/**
 * 请求诊断日志（RuoYi 风格运维可见性）
 */
public class RequestLoggingInterceptor implements HandlerInterceptor {

    private static final Logger log = LoggerFactory.getLogger(RequestLoggingInterceptor.class);

    @Override
    public boolean preHandle(@NonNull HttpServletRequest request, @NonNull HttpServletResponse response,
                             @NonNull Object handler) {
        String method = request.getMethod();
        String uri = request.getRequestURI();
        String query = request.getQueryString();
        Map<String, String[]> pmap = request.getParameterMap();
        String params = pmap.isEmpty()
                ? "{}"
                : pmap.entrySet().stream()
                .map(e -> e.getKey() + "=" + String.join(",", e.getValue()))
                .collect(Collectors.joining(", ", "{", "}"));
        String remote = request.getRemoteAddr();
        log.info("[HTTP] {} {}{} from {} params {}", method, uri,
                query == null ? "" : "?" + query, remote, params);
        return true;
    }
}
