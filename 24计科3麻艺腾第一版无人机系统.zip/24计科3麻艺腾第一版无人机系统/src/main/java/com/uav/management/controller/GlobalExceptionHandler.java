package com.uav.management.controller;

import org.apache.shiro.authz.AuthorizationException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(AuthorizationException.class)
    public ModelAndView handleAuthorization(HttpServletRequest req, AuthorizationException ex) {
        ModelAndView mv = new ModelAndView("unauthorized");
        mv.addObject("path", req.getRequestURI());
        mv.addObject("message", ex.getMessage());
        return mv;
    }
}
