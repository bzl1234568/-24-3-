package com.uav.management.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.env.EnvironmentPostProcessor;
import org.springframework.core.env.ConfigurableEnvironment;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * SQLite JDBC 不会自动创建数据库文件的父目录；数据源初始化早于 ApplicationRunner，
 * 因此在此阶段根据 jdbc:sqlite: 路径提前创建目录。
 */
public class SqliteDataDirectoryEnvironmentPostProcessor implements EnvironmentPostProcessor {

    @Override
    public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
        String url = environment.getProperty("spring.datasource.url");
        if (url == null || !url.startsWith("jdbc:sqlite:")) {
            return;
        }
        String pathPart = url.substring("jdbc:sqlite:".length()).trim();
        if (pathPart.isEmpty() || pathPart.startsWith(":memory:")) {
            return;
        }
        Path dbPath = Paths.get(pathPart).toAbsolutePath().normalize();
        Path parent = dbPath.getParent();
        if (parent == null) {
            return;
        }
        try {
            Files.createDirectories(parent);
        } catch (IOException e) {
            throw new UncheckedIOException("无法创建 SQLite 数据目录: " + parent, e);
        }
    }
}
