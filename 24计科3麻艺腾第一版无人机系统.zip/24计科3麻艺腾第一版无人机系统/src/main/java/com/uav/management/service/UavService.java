package com.uav.management.service;

import com.github.pagehelper.PageInfo;
import com.uav.management.domain.Uav;
import com.uav.management.domain.query.UavQuery;

import java.util.List;

public interface UavService {

    PageInfo<Uav> page(UavQuery query, int pageNum, int pageSize);

    Uav getById(Long id);

    void save(Uav uav);

    void removeByIds(List<Long> ids);
}
