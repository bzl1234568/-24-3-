package com.uav.management.domain.query;

import java.io.Serializable;

/**
 * 列表查询条件
 */
public class UavQuery implements Serializable {

    private static final long serialVersionUID = 1L;

    private String name;
    private String serialNo;
    private Integer status;

    /** 由服务层填充，供 MyBatis LIKE 双库兼容 */
    private String nameLike;
    private String serialNoLike;

    public String getNameLike() {
        return nameLike;
    }

    public void setNameLike(String nameLike) {
        this.nameLike = nameLike;
    }

    public String getSerialNoLike() {
        return serialNoLike;
    }

    public void setSerialNoLike(String serialNoLike) {
        this.serialNoLike = serialNoLike;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
