package com.uav.management.shiro;

import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;

import java.util.Arrays;
import java.util.HashSet;

/**
 * 演示账号：admin / admin123（生产环境请改为数据库或外部认证）
 */
public class UavUserRealm extends AuthorizingRealm {

    private static final String DEMO_USER = "admin";
    private static final String DEMO_PASS = "admin123";

    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        info.addRole("admin");
        info.addStringPermissions(new HashSet<>(Arrays.asList(
                "uav:list", "uav:query", "uav:add", "uav:edit", "uav:remove"
        )));
        return info;
    }

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        UsernamePasswordToken up = (UsernamePasswordToken) token;
        String username = up.getUsername();
        String password = new String(up.getPassword());
        if (!DEMO_USER.equals(username) || !DEMO_PASS.equals(password)) {
            throw new IncorrectCredentialsException("用户名或密码错误");
        }
        return new SimpleAuthenticationInfo(username, password, getName());
    }
}
