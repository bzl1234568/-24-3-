-- 在 Docker MySQL 客户端中执行本脚本：创建库、表并写入演示数据
CREATE DATABASE IF NOT EXISTS uav_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE uav_db;

DROP TABLE IF EXISTS uav;
CREATE TABLE uav (
    id                 BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    name               VARCHAR(100) NOT NULL COMMENT '名称',
    serial_no          VARCHAR(64)  NOT NULL COMMENT '机身序列号',
    status             TINYINT      NOT NULL DEFAULT 1 COMMENT '状态 1正常 0停用',
    ai_model           VARCHAR(128)          DEFAULT NULL COMMENT 'AI推断机型代号',
    ai_battery_mah     INT                   DEFAULT NULL COMMENT 'AI推断电池容量 mAh',
    ai_max_altitude_m  INT                   DEFAULT NULL COMMENT 'AI推断最大作业高度 m',
    ai_payload_kg      DECIMAL(6,2)          DEFAULT NULL COMMENT 'AI推断有效载荷 kg',
    ai_inference_json  TEXT                  DEFAULT NULL COMMENT 'AI推理附加信息 JSON',
    remark             VARCHAR(500)          DEFAULT NULL COMMENT '备注',
    create_time        DATETIME              DEFAULT NULL,
    update_time        DATETIME              DEFAULT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_uav_serial (serial_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='无人机信息';

INSERT INTO uav (name, serial_no, status, ai_model, ai_battery_mah, ai_max_altitude_m, ai_payload_kg, ai_inference_json, remark, create_time, update_time)
VALUES
('演示无人机-01', 'UAV-DEMO-0001', 1, 'Sim-AI-Quad-X4', 5200, 120, 1.20,
 '{"inference":"local-heuristic","confidence":0.82,"sensors":["RGB","IMU"],"windClass":"B"}',
 'MySQL 演示数据', NOW(), NOW()),
('演示无人机-02', 'UAV-DEMO-0002', 1, 'Sim-AI-Hex-Pro', 6800, 150, 2.50,
 '{"inference":"local-heuristic","confidence":0.76,"sensors":["RGB","LiDAR"],"windClass":"A"}',
 'MySQL 演示数据', NOW(), NOW());
